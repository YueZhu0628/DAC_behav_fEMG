# run.py file for DARDC.py
# coding=utf-8

# Use this script to run the experiment
# coding=utf-8
# import random

from src.constant import *   # task-specific global variables
from src import DARDC       # task-specific functions


## PHASE 0 - WELCOME ##
DARDC.show_instruction(INST_BEGIN, data=EXPDATA)


### ------------------------- 2-BACK PRACTICE PHASE ------------------------- ###
## PHASE 1 - PRACTICE 2-BACK PHASE - BEHAVIORAL ##
DARDC.show_instruction(INST_PRAC_2, data=EXPDATA)
A = DARDC.trial_nBack(thisISI=ISIs['1'], nLevel=2, phase='practice', block=0,
                    trialN=random.sample(trialNs_prac, 1)[0],
                    reminders=True, data=EXPDATA)  # return A
DARDC.check_A(A, A_min, A_max, ISI=ISIs['1'], nLevel=2, reminder=True)

toDo = DARDC.show_instruction(INST_TO_CALI, data=EXPDATA)
while toDo == 'left':
    DARDC.buffer(show="rePrac")

    A = DARDC.trial_nBack(thisISI=ISIs['1'], nLevel=2, phase='practice', block=0,
                        trialN=random.sample(trialNs_prac, 1)[0],
                        reminders=True, data=EXPDATA)  # return A
    DARDC.check_A(A, A_min, A_max, ISI=ISIs['1'], nLevel=2, reminder=True)

    toDo = DARDC.show_instruction(INST_TO_CALI, data=EXPDATA)
    if toDo == 'right':
        break


### ---------------------------- CALIBRATION PHASE ---------------------------- ###
## PHASE 2 - CALIBRATION PHASE - BEHAVIORAL ##
DARDC.show_instruction(INST_CALI, data=EXPDATA)

DARDC.buffer(show="start")
ISI_calibrated = DARDC.ISI_calibration(curr_ISI_level=10, data=EXPDATA)



### ------------------------- MAIN TASK PRACTICE PHASE ------------------------- ###
## PHASE 3 - 1-BACK PRACTICE PHASE ##
DARDC.show_instruction(INST_PRAC_1, data=EXPDATA)
# ----- practice with reminders ----- #
A = DARDC.trial_nBack(thisISI=ISIs['5'], nLevel=1, phase='practice', block=0,
                    trialN=random.sample(trialNs_prac, 1)[0],
                    reminders=True, data=EXPDATA)
DARDC.check_A(A, A_min, A_max, ISI=ISIs['5'], nLevel=1, reminder=True)
# practice again?
toDo = DARDC.show_instruction(INST_PRAC_1_NEXT, data=EXPDATA)
while toDo == 'left':
    DARDC.buffer(show="rePrac")
    A = DARDC.trial_nBack(thisISI=ISI_calibrated, nLevel=1, phase='practice', block=0,
                        trialN=random.sample(trialNs_prac, 1)[0],
                        reminders=True, data=EXPDATA)  # return A
    DARDC.check_A(A, A_min, A_max, ISI=ISI_calibrated, nLevel=1, reminder=True)
    toDo = DARDC.show_instruction(INST_PRAC_1_NEXT, data=EXPDATA)
    if toDo == 'right':
        break
# ----- practice without reminders ----- #
DARDC.buffer(show="start")
# 1-Back practice 1st trial
DARDC.trial_nBack(thisISI=ISI_calibrated, nLevel=1, phase='practice', block=0,
                    trialN=random.sample(trialNs_prac, 1)[0],
                    reminders=False, data=EXPDATA)
DARDC.buffer(show="end_seq")
# 1-Back practice 2nd trial
A = DARDC.trial_nBack(thisISI=ISI_calibrated, nLevel=1, phase='practice', block=0,
                    trialN=random.sample(trialNs_prac, 1)[0],
                    reminders=False, data=EXPDATA)  # return A
DARDC.check_A(A, A_min, A_max, ISI=ISI_calibrated, nLevel=1, reminder=False)

### ------ break ------ ###
DARDC.buffer(show="blank")


## PHASE 4 - 3-BACK PRACTICE PHASE ##
DARDC.show_instruction(INST_PRAC_3, data=EXPDATA)
# ----- practice with reminders ----- #
A = DARDC.trial_nBack(thisISI=ISIs['8'], nLevel=3, phase='practice', block=0,
                    trialN=random.sample(trialNs_prac, 1)[0],
                    reminders=True, data=EXPDATA)
DARDC.check_A(A, A_min, A_max, ISI=ISIs['8'], nLevel=3, reminder=True)
# practice again?
toDo = DARDC.show_instruction(INST_PRAC_3_NEXT, data=EXPDATA)
while toDo == 'left':
    DARDC.buffer(show="rePrac")
    A = DARDC.trial_nBack(thisISI=ISI_calibrated, nLevel=3, phase='practice', block=0,
                        trialN=random.sample(trialNs_prac, 1)[0],
                        reminders=True, data=EXPDATA)  # return A
    DARDC.check_A(A, A_min, A_max, ISI=ISI_calibrated, nLevel=3, reminder=True)
    toDo = DARDC.show_instruction(INST_PRAC_3_NEXT, data=EXPDATA)
    if toDo == 'right':
        break
# ----- practice without reminders ----- #
DARDC.buffer(show="start")
# 3-Back practice 1st trial
DARDC.trial_nBack(thisISI=ISI_calibrated, nLevel=3, phase='practice', block=0,
                    trialN=random.sample(trialNs_prac, 1)[0],
                    reminders=False, data=EXPDATA)
DARDC.buffer(show="end_seq")
# 3-Back practice 2nd trial
A = DARDC.trial_nBack(thisISI=ISI_calibrated, nLevel=3, phase='practice', block=0,
                    trialN=random.sample(trialNs_prac, 1)[0],
                    reminders=False, data=EXPDATA)  # return A
DARDC.check_A(A, A_min, A_max, ISI=ISI_calibrated, nLevel=3, reminder=False)

### ------ break ------ ###
DARDC.buffer(show="blank")


## PHASE 5 - RATING PRACTICE + MAIN PHASE ##
DARDC.show_instruction(INST_PRAC_main, data=EXPDATA)
DARDC.main_block(phase='PRACTICE', testISI=ISI_calibrated, data=EXPDATA, block=0, run=RUN)
### ------ break ------ ###
DARDC.buffer(show="blank")
DARDC.show_instruction(INST_PRAC_end, data=EXPDATA) # Experimenter click the right button



### ------------------------- MAIN TASK PHASE ------------------------- ###
## PHASE 6 - LEARNING PHASE ###
toDo = DARDC.show_instruction(INST_TEST, data=EXPDATA)
# practice again?
while toDo == 'left':
    DARDC.buffer(show="rePrac")
    # re-practice main task
    DARDC.show_instruction(INST_PRAC_main, data=EXPDATA, start_num=1)
    DARDC.buffer(show="start")
    DARDC.main_block(phase='PRACTICE', testISI=ISI_calibrated, data=EXPDATA, block=0, run=RUN)
    DARDC.buffer(show="blank")
    # until choose to start
    toDo = DARDC.show_instruction(INST_TEST, data=EXPDATA)
    if toDo == 'right':
        break

#  Block 1
DARDC.buffer(show="start_Test")
DARDC.main_block(phase='TEST', testISI=ISI_calibrated, data=EXPDATA, block=1, run=RUN)
# # only run Block 1
# # break for 2 minute
# DARDC.block_break_timer(120)
#
# #  Block 2
# DARDC.main_block(phase='TEST', testISI=ISI_calibrated, data=EXPDATA, block=2, run=RUN)

### ------ break ------ ###
DARDC.buffer(show="blank")


## PHASE 7 - OFFLINE-RATING (T1) ##
DARDC.show_instruction(INST_OFFLINE_RATING, data=EXPDATA)
### ------ break ------ ###
DARDC.buffer(show="blank")
### ------ rating ----- ###
DARDC.offline_rating(data=EXPDATA, timepoint="T1")
### ------ break ------ ###
DARDC.buffer(show="blank")


## PHASE 8 - TRUE CHOICE PAHSE ##
DARDC.show_instruction(INST_CHOICE_TRUE, data=EXPDATA)
### ------ break ------ ###
DARDC.buffer(show="blank")
### ------ Demand choice ----- ###
DARDC.demand_choice(testISI=ISI_calibrated, phase="Choice", type="True", data=EXPDATA)
### ------ break ------ ###
DARDC.buffer(show="blank")


## PHASE 9 - OFFLINE-RATING (T2) ##
DARDC.show_instruction(INST_OFFLINE_RATING, data=EXPDATA)
### ------ break ------ ###
DARDC.buffer(show="blank")
### ------ rating ----- ###
DARDC.offline_rating(data=EXPDATA, timepoint="T2")
### ------ break ------ ###
DARDC.buffer(show="blank")


## PHASE 10 - LEARNING-CHECK T1 ##
DARDC.show_instruction(INST_LEARNING_CHECK, data=EXPDATA)
### ------ break ------ ###
DARDC.buffer(show="blank")
DARDC.learning_check(data=EXPDATA, timepoint="T1")
### ------ break ------ ###
DARDC.buffer(show="blank")


## PHASE 11 - FALSE CHOICE PAHSE ##
DARDC.show_instruction(INST_CHOICE_FALSE, data=EXPDATA)
### ------ break ------ ###
DARDC.buffer(show="blank")
### ------ Demand choice ----- ###
DARDC.demand_choice(testISI=ISI_calibrated, phase="Choice", type="False", data=EXPDATA)
### ------ break ------ ###
DARDC.buffer(show="blank")


## PHASE 12 - OFFLINE-RATING (T3) ##
DARDC.show_instruction(INST_OFFLINE_RATING, data=EXPDATA)
### ------ break ------ ###
DARDC.buffer(show="blank")
### ------ rating ----- ###
DARDC.offline_rating(data=EXPDATA, timepoint="T3")
### ------ break ------ ###
DARDC.buffer(show="blank")


## PHASE 13 - LEARNING-CHECK T2 ##
DARDC.show_instruction(INST_LEARNING_CHECK, data=EXPDATA)
### ------ break ------ ###
DARDC.buffer(show="blank")
DARDC.learning_check(data=EXPDATA, timepoint="T2")
### ------ break ------ ###
DARDC.buffer(show="blank")


## PHASE 14 - DEMAND-RATING PHASE ##
DARDC.show_instruction(INST_DEMAND_RATING, data=EXPDATA)
### ------ break ------ ###
DARDC.buffer(show="blank")
### ------ rating ------ ###
DARDC.demand_rating(data=EXPDATA)
### ------ break ------ ###
DARDC.buffer(show="blank")


### ------------------------- END ------------------------- ###

## PHASE 15 - END - PSYCHOPY ##
DARDC.show_instruction(INST_END, data=EXPDATA)

### FINAL MESSAGE - TERMINAL ###
DARDC.terminal_final_msg()
WIN.flip()

### QUIT ###
core.quit()
EXPDATA.abort()
WIN.close()
